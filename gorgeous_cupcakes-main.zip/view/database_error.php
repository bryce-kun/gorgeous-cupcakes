<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>Connection Error</title>  
</head>

<body>
	<h1>Database Connection Error</h1>
	<p>There was an error connecting to the database.</p>
	<!-- display the error message -->
	<p>Error message: <?php echo $error_message; ?></p>
</body>
</html>